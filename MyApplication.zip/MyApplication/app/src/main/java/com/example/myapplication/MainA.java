package com.example.myapplication;

import android.app.Activity;

public class MainA extends Activity {
}
